require('dotenv').config()
const express  = require('express')
const mongoose = require('mongoose')
const cors     = require('cors')
const path     = require('path')
const fs       = require('fs')

const app = express()

// ── ENSURE UPLOADS DIR EXISTS ─────────────────────────
const uploadsDir = path.join(__dirname, 'uploads')
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true })

// ── CORS ──────────────────────────────────────────────
// Allow all localhost ports in dev + your production frontend URL
app.use(cors({
  origin: (origin, callback) => {
    // Allow requests with no origin (mobile apps, Postman, curl)
    if (!origin) return callback(null, true)
    // Allow any localhost port during development
    if (origin.match(/^http:\/\/localhost:\d+$/) || origin.match(/^http:\/\/127\.0\.0\.1:\d+$/)) {
      return callback(null, true)
    }
    // Allow your configured frontend URL (Vercel etc.)
    const allowed = (process.env.FRONTEND_URL || '').split(',').map(u => u.trim()).filter(Boolean)
    if (allowed.includes(origin)) return callback(null, true)
    // Block unknown origins in production
    callback(new Error(`CORS: origin ${origin} not allowed`))
  },
  credentials: true,
}))

// ── BODY PARSERS ──────────────────────────────────────
app.use(express.json())
app.use(express.urlencoded({ extended: true }))

// ── STATIC: serve uploaded photos ─────────────────────
app.use('/uploads', express.static(uploadsDir))

// ── ROUTES ────────────────────────────────────────────
app.use('/api/auth',    require('./routes/auth'))
app.use('/api/seed',    require('./routes/seed'))
app.use('/api/dresses', require('./routes/dresses'))
app.use('/api',         require('./routes/other'))

// ── HEALTH CHECK ──────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    message: 'Kriya Boutique API running',
    db: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected',
  })
})

// ── 404 HANDLER ───────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ error: `Route ${req.method} ${req.path} not found` })
})

// ── ERROR HANDLER ─────────────────────────────────────
app.use((err, req, res, next) => {
  console.error('❌', err.message)
  // Don't leak CORS errors with 500 — use 403
  if (err.message?.startsWith('CORS:')) return res.status(403).json({ error: err.message })
  res.status(500).json({ error: err.message || 'Something went wrong' })
})

// ── CONNECT DB & START ────────────────────────────────
const PORT = process.env.PORT || 5000

mongoose
  .connect(process.env.MONGODB_URI)
  .then(async () => {
    console.log('✅ MongoDB connected')
    // Seed default brand settings if DB is empty
    await seedBrandIfEmpty()
    app.listen(PORT, () => {
      console.log(`🚀 Kriya Boutique API → http://localhost:${PORT}`)
      console.log(`   Health: http://localhost:${PORT}/api/health`)
      console.log(`   Admin login: ${process.env.ADMIN_USERNAME} / ${process.env.ADMIN_PASSWORD}`)
    })
  })
  .catch(err => {
    console.error('❌ MongoDB connection failed:', err.message)
    process.exit(1)
  })

// ── SEED DEFAULT BRAND SETTINGS ───────────────────────
async function seedBrandIfEmpty() {
  const { Brand } = require('./models')
  const count = await Brand.countDocuments()
  if (count > 0) return // already seeded

  const defaults = {
    name:      'Kriya Boutique',
    tagline:   'Indian Couture, Reimagined',
    about:     'Born in the heart of Jaipur, Kriya Boutique is a bespoke Indian couture house dedicated to handcrafted lehengas, bridal wear, and festive outfits.',
    founded:   '2018',
    location:  'Jaipur, Rajasthan',
    address:   'B-12, MI Road, Near Ajmeri Gate, Jaipur, Rajasthan 302001',
    phone:     '+91 98765 43210',
    whatsapp:  '919876543210',
    instagram: 'kriyaboutique',
    instagramUrl: 'https://instagram.com/kriyaboutique',
    email:     'hello@kriyaboutique.com',
    mapEmbed:  'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3559.3!2d75.7873!3d26.9124!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjbCsDU0JzQ0LjYiTiA3NcKwNDcnMTQuMyJF!5e0!3m2!1sen!2sin!4v1234567890',
  }

  await Promise.all(
    Object.entries(defaults).map(([key, value]) =>
      Brand.findOneAndUpdate({ key }, { key, value }, { upsert: true, new: true })
    )
  )
  console.log('✅ Default brand settings seeded')
}
