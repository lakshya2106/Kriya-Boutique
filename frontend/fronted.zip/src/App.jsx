import { PageLoader, WhatsAppFloat } from './components/FloatingButtons'
import Cursor from './components/Cursor'
import Navbar from './components/Navbar'
import Hero from './components/Hero'
import DressCard from './components/DressCard'
import Collections from './components/Collections'
import About from './components/About'
import Testimonials from './components/Testimonials'
import InstagramGallery from './components/InstagramGallery'
import Contact from './components/Contact'
import { Marquee, Intro, Quote, Process, Footer } from './components/Sections'
import { useDresses, useBrand } from './hooks/useAPI'
import { PROCESS_STEPS } from './data/site'

export default function App() {
  const { data: BRAND }      = useBrand()
  const { data: rawDresses } = useDresses()
  const DRESSES = Array.isArray(rawDresses) ? rawDresses : []

  // Featured = new + bestseller, max 3
  const featured = DRESSES
    .filter(d => d.badge === 'new' || d.badge === 'bestseller')
    .slice(0, 3)

  return (
    <>
      <PageLoader />
      <WhatsAppFloat />
      <Cursor />
      <Navbar />
      <Hero />
      <Marquee />
      <Intro />

      {/* Featured dress cards */}
      {featured.length > 0 && (
        <section id="featured">
          {featured.map((dress, i) => (
            <DressCard key={dress._id || dress.id} dress={dress} index={i} />
          ))}
        </section>
      )}

      <Collections />
      <About />
      <Process steps={PROCESS_STEPS} />
      <Quote />
      <Testimonials />
      <InstagramGallery />
      <Contact />
      <Footer brand={BRAND} />
    </>
  )
}
