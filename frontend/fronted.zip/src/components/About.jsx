import { useInView } from '../hooks/useScroll'
import { useBrand, useHero } from '../hooks/useAPI'
import styles from './About.module.css'

export default function About() {
  const { ref: lRef, visible: lVis } = useInView(0.15)
  const { ref: rRef, visible: rVis } = useInView(0.15)
  const { data: BRAND }     = useBrand()
  const { data: heroPhoto } = useHero()

  return (
    <section className={styles.section} id="about">
      <div className={styles.inner}>
        <div ref={lRef} className={`${styles.photoSide} ${lVis ? styles.visible : ''}`}>
          <div className={styles.photoFrame}>
            <img src={heroPhoto || '/hero-model.png'} alt="Kriya Boutique" className={styles.photo} />
            <div className={styles.photoOverlay} />
          </div>
          <div className={styles.photoLabel}>
            <span>Est. {BRAND.founded}</span>
            <span>·</span>
            <span>{BRAND.location}</span>
          </div>
          <div className={styles.photoBorder} />
        </div>

        <div ref={rRef} className={`${styles.textSide} ${rVis ? styles.visible : ''}`}>
          <span className={styles.eyebrow}>Our Story</span>
          <h2 className={styles.title}>
            Crafted in Jaipur,<br />
            <em>worn everywhere</em>
          </h2>
          <p className={styles.para}>{BRAND.about}</p>
          <p className={styles.para}>
            We believe every woman deserves a lehenga that fits not just her body but her soul.
            Our karigars bring decades of inherited knowledge — zardozi, gota patti,
            banarasi weaving — into every single piece we create.
          </p>

          <div className={styles.stats}>
            {[
              { n: '500+', l: 'Happy Brides'   },
              { n: '7+',   l: 'Years of Craft' },
              { n: '100%', l: 'Handcrafted'    },
            ].map(s => (
              <div key={s.l} className={styles.stat}>
                <span className={styles.statN}>{s.n}</span>
                <span className={styles.statL}>{s.l}</span>
              </div>
            ))}
          </div>

          <a href="#contact" className={styles.cta}>Meet us in Jaipur →</a>
        </div>
      </div>
    </section>
  )
}
