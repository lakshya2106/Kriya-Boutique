import { useInView } from '../hooks/useScroll'
import styles from './Sections.module.css'

/* ── MARQUEE ─────────────────────────────────────────── */
export function Marquee() {
  const items = [
    'Bridal Lehengas', 'Bespoke Couture', 'Jaipur Atelier',
    'Handcrafted Zardozi', 'Limited Pieces', 'For Every Woman',
  ]
  return (
    <div className={styles.marqueeWrap}>
      <div className={styles.marqueeInner}>
        {[...items, ...items].map((item, i) => (
          <span key={i} className={styles.marqueeItem}>
            {item} <span className={styles.dot}>◆</span>
          </span>
        ))}
      </div>
    </div>
  )
}

/* ── INTRO ───────────────────────────────────────────── */
export function Intro() {
  const { ref: lRef, visible: lVis } = useInView(0.15)
  const { ref: rRef, visible: rVis } = useInView(0.15)
  return (
    <section className={styles.intro} id="atelier">
      <div ref={lRef} className={`${styles.introLeft} ${lVis ? styles.visible : ''}`}>
        <span className={styles.tag}>Our Philosophy</span>
        <h2>Every lehenga is a<br /><em>living poem</em><br />worn by a queen</h2>
      </div>
      <div ref={rRef} className={`${styles.introRight} ${rVis ? styles.visible : ''}`}>
        <p>At Kriya Boutique, we create bespoke Indian couture — lehengas, bridal wear, and festive outfits crafted entirely by hand in our Jaipur atelier. Each piece is a dialogue between heritage craft and contemporary vision.</p>
        <p>We work in small batches, never mass production. The result is something rare: a lehenga that moves with you, celebrates your culture, and tells your story.</p>
      </div>
    </section>
  )
}

/* ── QUOTE ───────────────────────────────────────────── */
export function Quote() {
  const { ref, visible } = useInView(0.2)
  return (
    <div className={styles.quoteSec} ref={ref}>
      <div className={`${styles.quoteInner} ${visible ? styles.visible : ''}`}>
        <p className={styles.quoteText}>
          "She wears her culture like armour — beautiful, fearless, and unforgettable"
        </p>
        <span className={styles.quoteAttr}>— Kriya Boutique, Jaipur</span>
      </div>
    </div>
  )
}

/* ── PROCESS ─────────────────────────────────────────── */
export function Process({ steps }) {
  const { ref, visible } = useInView(0.1)
  const list = steps || []
  return (
    <section className={styles.process} id="process" ref={ref}>
      <h2 className={`${styles.processTitle} ${visible ? styles.visible : ''}`}>How we create</h2>
      <div className={styles.steps}>
        {list.map((s, i) => (
          <div key={i} className={`${styles.step} ${visible ? styles.visible : ''}`}
            style={{ transitionDelay: `${i * 0.12}s` }}>
            <div className={styles.stepIco}>{s.icon}</div>
            <div className={styles.stepN}>Step {s.num}</div>
            <div className={styles.stepT}>{s.title}</div>
            <p className={styles.stepD}>{s.desc}</p>
          </div>
        ))}
      </div>
    </section>
  )
}

/* Contact is now in Contact.jsx */

/* ── FOOTER ──────────────────────────────────────────── */
export function Footer({ brand = {} }) {
  return (
    <footer className={styles.footer}>
      <div className={styles.footTop}>
        <div>
          <div className={styles.footLogo}>{brand.name}</div>
          <p className={styles.footTag}>Bespoke Indian couture for women who believe that what they wear is as important as how they feel. Every stitch, intentional.</p>
          <p className={styles.footLocation}>📍 {brand.location}</p>
        </div>
        {[
          { h: 'Collections', links: ['Bridal Lehengas', 'Heritage Couture', 'Contemporary', 'Festive Wear'] },
          { h: 'Atelier', links: ['Our Story', 'The Process', 'Fabrics', 'Lookbook'] },
          { h: 'Connect', links: ['Book a Fitting', 'WhatsApp', 'Instagram', 'Pinterest'] },
        ].map(col => (
          <div key={col.h} className={styles.footCol}>
            <h4>{col.h}</h4>
            <ul>{col.links.map(l => <li key={l}><a href="#">{l}</a></li>)}</ul>
          </div>
        ))}
      </div>
      <div className={styles.footBottom}>
        <span>© 2025 {brand.name}. All rights reserved.</span>
        <span>Handcrafted with love · {brand.location}</span>
      </div>
    </footer>
  )
}
