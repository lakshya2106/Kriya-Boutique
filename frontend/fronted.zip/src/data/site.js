// ═══════════════════════════════════════════════════════
//  KRIYA BOUTIQUE — SITE DATA
//  Edit this file to update everything on the website
// ═══════════════════════════════════════════════════════

export const BRAND = {
  name: 'Kriya Boutique',
  tagline: 'Indian Couture, Reimagined',
  about: 'Born in the heart of Jaipur, Kriya Boutique is a bespoke Indian couture house dedicated to handcrafted lehengas, bridal wear, and festive outfits. Every piece is made with intention — each stitch a love letter to the woman who wears it.',
  founded: '2018',
  location: 'Jaipur, Rajasthan',
  address: 'B-12, MI Road, Near Ajmeri Gate, Jaipur, Rajasthan 302001',
  phone: '+91 98765 43210',
  whatsapp: '919876543210', // no + or spaces
  instagram: 'kriyaboutique',
  instagramUrl: 'https://instagram.com/kriyaboutique',
  email: 'hello@kriyaboutique.com',
  mapEmbed: 'https://www.google.com/maps/embed?pb=!4v1773397616175!6m8!1m7!1sYoE6g0qarL0Z5MOPFvTDYw!2m2!1d24.5793947526658!2d73.66108021768599!3f251.48618316206918!4f-3.442943682242216!5f0.7820865974627469" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade',
}

// ── COLLECTION CATEGORIES ────────────────────────────
// Add / remove categories freely
export const CATEGORIES = [
  { id: 'all',         label: 'All',              color: '#c8a45a' },
  { id: 'bridal',      label: 'Bridal',           color: '#c4766a' },
  { id: 'festive',     label: 'Festive',          color: '#9b7fc4' },
  { id: 'indo-western',label: 'Indo-Western',     color: '#5a8a6e' },
  { id: 'bespoke',     label: 'Custom / Bespoke', color: '#c8a45a' },
  { id: 'new',         label: 'New Arrivals',     color: '#e0a870' },
]

// ── DRESSES / COLLECTIONS ────────────────────────────
// Add as many dresses as you want here!
// badge: 'new' | 'sold-out' | 'bestseller' | null
export const DRESSES = [
  {
    id: 1,
    num: '01',
    category: 'bridal',
    badge: 'bestseller',
    tag: 'Bridal Collection',
    name: 'Hara Gulzar',
    nameEn: 'The Green Garden',
    desc: 'A breathtaking emerald and fuchsia lehenga with intricate gold zardozi embroidery throughout the blouse and skirt. The double-layered skirt flares dramatically with a rich gold gota patti border.',
    fabric: 'Raw Silk & Net',
    work: 'Zardozi & Gota Patti',
    sizes: 'XS — 3XL',
    lead: '3–4 weeks',
    price: '₹45,000',
    swatches: ['#2d8a4e', '#e0357a', '#c8a45a'],
    colors: ['Emerald', 'Fuchsia', 'Gold'],
    photos: ['/lehenga1.png', '/lehenga1.png', '/lehenga1.png'],
    accentColor: '#2d8a4e',
    bgGlow: 'radial-gradient(ellipse at 50% 60%, rgba(45,138,78,0.18) 0%, transparent 65%)',
  },
  {
    id: 2,
    num: '02',
    category: 'bespoke',
    badge: 'new',
    tag: 'Custom Couture',
    name: 'Rang Mahal',
    nameEn: 'Palace of Colours',
    desc: 'A magnificent multi-panel lehenga in royal purple, teal, and sky blue with Banarasi brocade panels. The swirling skirt creates a kaleidoscope of colour in motion.',
    fabric: 'Banarasi Silk & Organza',
    work: 'Banarasi Brocade & Zari',
    sizes: 'XS — 2XL',
    lead: '5–6 weeks',
    price: '₹65,000',
    swatches: ['#5a1e9e', '#1a7a5e', '#a8c8e0'],
    colors: ['Royal Purple', 'Teal', 'Sky Blue'],
    photos: ['/lehenga2.png', '/lehenga2.png', '/lehenga2.png'],
    accentColor: '#5a1e9e',
    bgGlow: 'radial-gradient(ellipse at 50% 55%, rgba(90,30,158,0.2) 0%, transparent 65%)',
  },
  {
    id: 3,
    num: '03',
    category: 'festive',
    badge: null,
    tag: 'Festive Wear',
    name: 'Lavender Safar',
    nameEn: 'The Lavender Journey',
    desc: 'A modern lavender lehenga in crushed velvet with silver sequin borders and tiered hem detailing. Perfect for sangeet, receptions, and festive occasions.',
    fabric: 'Crushed Velvet & Georgette',
    work: 'Sequence & Silver Lace',
    sizes: 'XS — 4XL',
    lead: '2–3 weeks',
    price: '₹35,000',
    swatches: ['#9b7fc4', '#c0b8d8', '#b8b8c8'],
    colors: ['Lavender', 'Lilac', 'Silver'],
    photos: ['/lehenga3.png', '/lehenga3.png', '/lehenga3.png'],
    accentColor: '#9b7fc4',
    bgGlow: 'radial-gradient(ellipse at 50% 55%, rgba(155,127,196,0.2) 0%, transparent 65%)',
  },
  {
    id: 4,
    num: '04',
    category: 'bespoke',
    badge: 'new',
    tag: 'Signature Bespoke',
    name: 'Rang Bahar',
    nameEn: 'Festival of Colours',
    desc: 'A masterpiece patchwork lehenga combining the finest fabrics — silks, brocades, velvets — in a celebration of colour and craft. Truly one of a kind.',
    fabric: 'Mixed Silks & Brocade',
    work: 'Patchwork & Zari',
    sizes: 'Custom only',
    lead: '6–8 weeks',
    price: '₹80,000',
    swatches: ['#8a3a20', '#5a1e9e', '#2d8a4e'],
    colors: ['Rust', 'Purple', 'Green'],
    photos: ['/hero-model.png', '/hero-model.png', '/hero-model.png'],
    accentColor: '#8a3a20',
    bgGlow: 'radial-gradient(ellipse at 50% 55%, rgba(138,58,32,0.2) 0%, transparent 65%)',
  },
  // ── ADD MORE DRESSES HERE ──────────────────────────
  // { id: 5, category: 'indo-western', badge: 'new', ... }
]

// Featured dresses shown in hero spotlight (use dress IDs)
export const FEATURED_IDS = [4, 2, 1]

// ── TESTIMONIALS ─────────────────────────────────────
export const TESTIMONIALS = [
  {
    id: 1,
    name: 'Priya Sharma',
    occasion: 'Bridal Lehenga — December 2024',
    rating: 5,
    text: ' ',
    location: 'Jaipur',
  },
  {
    id: 2,
    name: 'Meera Agarwal',
    occasion: 'Custom Sangeet Outfit — October 2024',
    rating: 5,
    text: 'The bespoke service is worth every rupee. They understood exactly what I wanted and delivered something even more beautiful than I had imagined. The fitting sessions were so personal and lovely.',
    location: 'Delhi',
  },
  {
    id: 3,
    name: 'Ananya Patel',
    occasion: 'Festive Lehenga — November 2024',
    rating: 5,
    text: 'Ordered a festive lehenga for Diwali. It arrived on time, perfectly fitted, and the colours were even more vibrant in person than in the photos. Will definitely order again!',
    location: 'Mumbai',
  },
  {
    id: 4,
    name: 'Riya Joshi',
    occasion: 'Reception Lehenga — January 2025',
    rating: 5,
    text: 'From the first consultation to final delivery, the entire experience was magical. The team is so patient and creative. My lehenga was the talk of the reception!',
    location: 'Jaipur',
  },
  {
    id: 5,
    name: 'Kavya Mehta',
    occasion: 'Indo-Western Set — March 2025',
    rating: 5,
    text: 'I wanted something that blended traditional and modern — and they nailed it completely. My outfit was unique, comfortable, and absolutely gorgeous. Highly recommend!',
    location: 'Bangalore',
  },
]

// ── INSTAGRAM GALLERY ────────────────────────────────
// Replace these with your actual Instagram photo URLs
// or local paths like '/insta1.jpg'
export const INSTAGRAM_POSTS = [
  { id: 1, photo: '/lehenga1.png',    caption: 'Hara Gulzar — Emerald Dreams', likes: '2.4k' },
  { id: 2, photo: '/lehenga2.png',    caption: 'Rang Mahal — Palace of Colours', likes: '3.1k' },
  { id: 3, photo: '/lehenga3.png',    caption: 'Lavender Safar — Soft & Dreamy', likes: '1.8k' },
  { id: 4, photo: '/hero-model.png',  caption: 'Rang Bahar — One of a Kind', likes: '4.2k' },
  { id: 5, photo: '/lehenga1.png',    caption: 'Bridal Season 2025', likes: '2.9k' },
  { id: 6, photo: '/lehenga3.png',    caption: 'Made with love in Jaipur', likes: '1.5k' },
]

// ── PROCESS STEPS ────────────────────────────────────
export const PROCESS_STEPS = [
  {
    num: '01',
    icon: '✦',
    title: 'Consultation',
    desc: 'We begin with a personal meeting — in-person at our Jaipur atelier or via video call — to understand your occasion, vision, measurements, and the story you want to wear.',
  },
  {
    num: '02',
    icon: '◈',
    title: 'Design & Fabric',
    desc: 'Our designers sketch custom concepts and select fabrics — silks, organzas, banarasi weaves — from our curated collection. You approve every detail before we begin.',
  },
  {
    num: '03',
    icon: '❋',
    title: 'Craft & Fittings',
    desc: 'Two to three fittings refine every pleat, embroidery, and hem. Our karigars work by hand — the embroidery alone can take weeks.',
  },
  {
    num: '04',
    icon: '◎',
    title: 'Delivery',
    desc: 'Your lehenga arrives in our signature box, steamed and preserved, ready for your most unforgettable moment. We ship across India and internationally.',
  },
]
