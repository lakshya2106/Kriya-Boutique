import { useState, useEffect } from 'react'
import { dressAPI, categoryAPI, testimonialAPI, instaAPI, brandAPI, heroAPI } from '../services/api'
import {
  DRESSES      as DEFAULT_DRESSES,
  CATEGORIES   as DEFAULT_CATEGORIES,
  TESTIMONIALS as DEFAULT_TESTIMONIALS,
  INSTAGRAM_POSTS as DEFAULT_INSTA,
  BRAND        as DEFAULT_BRAND,
} from '../data/site'

// ── GENERIC FETCH HOOK ────────────────────────────────
// - starts with fallback immediately (no flash of empty)
// - replaces with live data when API responds
// - falls back to static data silently on error
function useFetch(fetcher, fallback) {
  const [data,    setData]    = useState(fallback)
  const [loading, setLoading] = useState(true)
  const [error,   setError]   = useState(null)

  useEffect(() => {
    let cancelled = false
    setLoading(true)
    fetcher()
      .then(d => {
        if (!cancelled) {
          // Never replace a valid fallback with null/undefined
          setData(d ?? fallback)
        }
      })
      .catch(e => {
        if (!cancelled) {
          setError(e)
          setData(fallback) // keep showing static data on error
        }
      })
      .finally(() => { if (!cancelled) setLoading(false) })
    return () => { cancelled = true }
  }, [])

  return { data, loading, error }
}

export function useDresses(params = {}) {
  return useFetch(
    () => dressAPI.getAll(params).then(d => Array.isArray(d) ? d : DEFAULT_DRESSES),
    DEFAULT_DRESSES
  )
}

export function useCategories() {
  return useFetch(
    () => categoryAPI.getAll().then(d => Array.isArray(d) ? d : DEFAULT_CATEGORIES),
    DEFAULT_CATEGORIES
  )
}

export function useTestimonials() {
  return useFetch(
    () => testimonialAPI.getAll().then(d => Array.isArray(d) ? d : DEFAULT_TESTIMONIALS),
    DEFAULT_TESTIMONIALS
  )
}

export function useInsta() {
  return useFetch(
    () => instaAPI.getAll().then(d => Array.isArray(d) ? d : DEFAULT_INSTA),
    DEFAULT_INSTA
  )
}

export function useBrand() {
  return useFetch(
    () => brandAPI.get().then(obj => {
      if (!obj || typeof obj !== 'object') return DEFAULT_BRAND
      return { ...DEFAULT_BRAND, ...obj }
    }),
    DEFAULT_BRAND
  )
}

export function useHero() {
  return useFetch(
    () => heroAPI.get().then(r => r?.photo || '/hero-model.png'),
    '/hero-model.png'
  )
}
